#
# TABLE STRUCTURE FOR: backup
#

DROP TABLE IF EXISTS backup;

CREATE TABLE `backup` (
  `backup_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(255) NOT NULL,
  `backup_location` varchar(255) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`backup_id`),
  UNIQUE KEY `backup_name_UNIQUE` (`backup_name`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

INSERT INTO backup (`backup_id`, `backup_name`, `backup_location`, `created_date`) VALUES (29, '2fb1b5731ceb4a284a3bd9ec57c6234d_site.zip', 'backups/sites/', '2016-06-14 15:58:41');


#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS ci_sessions;

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d328e8f07ac2b63c682190cf0d5f4853', '::1', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36', 1465907698, 'a:15:{s:9:\"user_data\";s:0:\"\";s:9:\"user_name\";s:8:\"measurem\";s:4:\"name\";s:11:\"Super Admin\";s:11:\"employee_id\";s:1:\"0\";s:17:\"employee_login_id\";s:1:\"0\";s:8:\"loggedin\";b:1;s:9:\"user_type\";s:1:\"1\";s:8:\"user_pic\";s:0:\"\";s:3:\"url\";s:15:\"admin/dashboard\";s:12:\"user_country\";s:1:\"0\";s:13:\"currency_code\";s:3:\"USD\";s:14:\"menu_active_id\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"0\";}s:13:\"business_info\";O:8:\"stdClass\":8:{s:19:\"business_profile_id\";s:1:\"1\";s:12:\"company_name\";s:23:\"Measurement Systems LTD\";s:4:\"logo\";s:0:\"\";s:9:\"full_path\";N;s:5:\"email\";s:29:\"info@measurementsystems.co.ke\";s:7:\"address\";s:5:\"00300\";s:5:\"phone\";s:10:\"0726574998\";s:8:\"currency\";s:3:\"USD\";}s:26:\"flash:old:referrer_url_key\";s:19:\"admin/backup/backup\";s:26:\"flash:new:referrer_url_key\";s:19:\"admin/backup/backup\";}');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d9fec47cea1fdaeab30f6727f8a24fe4', '::1', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36', 1465912466, 'a:14:{s:9:\"user_data\";s:0:\"\";s:9:\"user_name\";s:8:\"measurem\";s:4:\"name\";s:11:\"Super Admin\";s:11:\"employee_id\";s:1:\"0\";s:17:\"employee_login_id\";s:1:\"0\";s:8:\"loggedin\";b:1;s:9:\"user_type\";s:1:\"1\";s:8:\"user_pic\";s:0:\"\";s:3:\"url\";s:15:\"admin/dashboard\";s:12:\"user_country\";s:1:\"0\";s:13:\"currency_code\";s:3:\"USD\";s:14:\"menu_active_id\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"0\";}s:13:\"business_info\";O:8:\"stdClass\":8:{s:19:\"business_profile_id\";s:1:\"1\";s:12:\"company_name\";s:23:\"Measurement Systems LTD\";s:4:\"logo\";s:0:\"\";s:9:\"full_path\";N;s:5:\"email\";s:29:\"info@measurementsystems.co.ke\";s:7:\"address\";s:5:\"00300\";s:5:\"phone\";s:10:\"0726574998\";s:8:\"currency\";s:3:\"USD\";}s:26:\"flash:old:referrer_url_key\";s:19:\"admin/backup/backup\";}');


#
# TABLE STRUCTURE FOR: currency_converter
#

DROP TABLE IF EXISTS currency_converter;

CREATE TABLE `currency_converter` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `_from` varchar(5) NOT NULL,
  `_to` varchar(5) NOT NULL,
  `rates` varchar(10) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO currency_converter (`id`, `_from`, `_to`, `rates`, `created`, `modified`) VALUES (1, 'USD', 'KES', '101.1385', '2016-05-22 10:26:24', '2016-06-14 11:54:44');
INSERT INTO currency_converter (`id`, `_from`, `_to`, `rates`, `created`, `modified`) VALUES (2, 'USD', 'UGX', '3350.0000', '2016-05-22 12:57:36', '2016-06-14 14:19:41');
INSERT INTO currency_converter (`id`, `_from`, `_to`, `rates`, `created`, `modified`) VALUES (5, 'USD', 'BWP', '11.1615', '2016-05-22 17:40:17', '2016-06-02 14:20:38');
INSERT INTO currency_converter (`id`, `_from`, `_to`, `rates`, `created`, `modified`) VALUES (6, 'USD', 'TZS', '2191.3501', '2016-05-23 09:37:18', '2016-05-23 10:38:02');


#
# TABLE STRUCTURE FOR: installer
#

DROP TABLE IF EXISTS installer;

CREATE TABLE `installer` (
  `id` int(1) NOT NULL,
  `installer_flag` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO installer (`id`, `installer_flag`) VALUES (1, 1);


#
# TABLE STRUCTURE FOR: tbl_activity
#

DROP TABLE IF EXISTS tbl_activity;

CREATE TABLE `tbl_activity` (
  `activityId` int(5) NOT NULL AUTO_INCREMENT,
  `userId` int(5) NOT NULL DEFAULT '0',
  `activityTitle` text NOT NULL,
  `activityDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ipAddress` varchar(15) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`activityId`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (1, 0, 'Super Admin logged in', '2016-06-14 08:51:13', '::1', 0);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (2, 0, 'Super Admin edited a country:Kenya to Kenyaz', '2016-06-14 09:02:28', '::1', 0);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (3, 0, 'Super Admin edited a country:Kenyaz to Kenya', '2016-06-14 09:02:36', '::1', 0);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (9, 0, 'Super Admin generated a receipt for order:#11', '2016-06-14 09:31:05', '::1', 0);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (8, 0, 'Super Admin generated a quotation for order:#11', '2016-06-14 09:29:46', '::1', 0);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (7, 0, 'Super Admin added a product:Tissues', '2016-06-14 09:12:09', '::1', 0);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (10, 0, 'Super Admin logged Out', '2016-06-14 09:31:24', '::1', 0);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (11, 1, 'Wendy Makena logged in', '2016-06-14 09:31:31', '::1', 3);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (12, 1, 'Wendy Makena generated a quotation for order:#4', '2016-06-14 09:32:28', '::1', 3);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (13, 1, 'Wendy Makena emailed a quotation for order:#4 to wendy@tharaka.com', '2016-06-14 09:32:33', '::1', 3);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (14, 1, 'Wendy Makena logged Out', '2016-06-14 10:06:18', '::1', 3);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (15, 0, 'Super Admin logged in', '2016-06-14 10:06:24', '::1', 0);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (16, 0, 'Super Admin logged in', '2016-06-14 12:47:45', '::1', 0);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (17, 0, 'Super Admin logged Out', '2016-06-14 14:34:58', '::1', 0);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (18, 0, 'Super Admin logged in', '2016-06-14 14:35:04', '::1', 0);
INSERT INTO tbl_activity (`activityId`, `userId`, `activityTitle`, `activityDate`, `ipAddress`, `country_id`) VALUES (19, 0, 'Super Admin logged in', '2016-06-14 15:54:32', '::1', 0);


#
# TABLE STRUCTURE FOR: tbl_attribute
#

DROP TABLE IF EXISTS tbl_attribute;

CREATE TABLE `tbl_attribute` (
  `attribute_id` int(5) NOT NULL AUTO_INCREMENT,
  `product_id` int(5) NOT NULL,
  `attribute_name` varchar(100) NOT NULL,
  `attribute_value` text NOT NULL,
  PRIMARY KEY (`attribute_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO tbl_attribute (`attribute_id`, `product_id`, `attribute_name`, `attribute_value`) VALUES (1, 1, 'Color', 'red');
INSERT INTO tbl_attribute (`attribute_id`, `product_id`, `attribute_name`, `attribute_value`) VALUES (2, 1, 'Color', 'Grey');


#
# TABLE STRUCTURE FOR: tbl_attribute_set
#

DROP TABLE IF EXISTS tbl_attribute_set;

CREATE TABLE `tbl_attribute_set` (
  `attribute_set_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(100) NOT NULL,
  PRIMARY KEY (`attribute_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO tbl_attribute_set (`attribute_set_id`, `attribute_name`) VALUES (1, 'Color');


#
# TABLE STRUCTURE FOR: tbl_business_profile
#

DROP TABLE IF EXISTS tbl_business_profile;

CREATE TABLE `tbl_business_profile` (
  `business_profile_id` int(2) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) NOT NULL,
  `logo` varchar(150) DEFAULT NULL,
  `full_path` varchar(150) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  PRIMARY KEY (`business_profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO tbl_business_profile (`business_profile_id`, `company_name`, `logo`, `full_path`, `email`, `address`, `phone`, `currency`) VALUES (1, 'Measurement Systems LTD', '', NULL, 'info@measurementsystems.co.ke', '00300', '0726574998', 'USD');


#
# TABLE STRUCTURE FOR: tbl_campaign
#

DROP TABLE IF EXISTS tbl_campaign;

CREATE TABLE `tbl_campaign` (
  `campaign_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_name` varchar(128) NOT NULL,
  `subject` varchar(128) NOT NULL,
  `email_body` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(128) NOT NULL,
  PRIMARY KEY (`campaign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO tbl_campaign (`campaign_id`, `campaign_name`, `subject`, `email_body`, `date`, `created_by`) VALUES (1, 'test', 'tonini46@gmail.com', '<p>hey</p>\r\n<p>test</p>\r\n<p>test</p>\r\n<p>test</p>', '2016-06-05 10:25:51', 'Super Admin');


#
# TABLE STRUCTURE FOR: tbl_campaign_result
#

DROP TABLE IF EXISTS tbl_campaign_result;

CREATE TABLE `tbl_campaign_result` (
  `campaign_result_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) NOT NULL,
  `campaign_name` varchar(128) NOT NULL,
  `subject` varchar(128) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `send_by` varchar(128) NOT NULL,
  PRIMARY KEY (`campaign_result_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_category
#

DROP TABLE IF EXISTS tbl_category;

CREATE TABLE `tbl_category` (
  `category_id` int(5) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO tbl_category (`category_id`, `category_name`, `created_datetime`) VALUES (1, 'Total Station', '2016-05-09 11:11:50');
INSERT INTO tbl_category (`category_id`, `category_name`, `created_datetime`) VALUES (2, 'Toiletries', '2016-05-10 10:23:37');


#
# TABLE STRUCTURE FOR: tbl_country
#

DROP TABLE IF EXISTS tbl_country;

CREATE TABLE `tbl_country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `currency` varchar(5) NOT NULL,
  `logo` varchar(300) NOT NULL,
  `full_path` varchar(300) NOT NULL,
  PRIMARY KEY (`country_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `currency` (`currency`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO tbl_country (`country_id`, `name`, `currency`, `logo`, `full_path`) VALUES (1, 'Kenya', 'KES', 'img/uploads/Kenya.png', 'C:/xampp/htdocs/inventory/easy_inventory/img/uploads/1.png');
INSERT INTO tbl_country (`country_id`, `name`, `currency`, `logo`, `full_path`) VALUES (2, 'Botswana', 'BWP', 'img/uploads/Botswana.png', 'C:/xampp/htdocs/inventory/easy_inventory/img/uploads/11.png');
INSERT INTO tbl_country (`country_id`, `name`, `currency`, `logo`, `full_path`) VALUES (3, 'Uganda', 'UGX', 'img/uploads/Uganda.png', 'C:/xampp/htdocs/inventory/easy_inventory/img/uploads/12.png');


#
# TABLE STRUCTURE FOR: tbl_customer
#

DROP TABLE IF EXISTS tbl_customer;

CREATE TABLE `tbl_customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_code` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `discount` varchar(100) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO tbl_customer (`customer_id`, `customer_code`, `customer_name`, `email`, `phone`, `address`, `discount`, `country_id`) VALUES (1, 92026951, 'SUSAN CLEMENT', 'tonini46@gmail.com', '0726574998', '<p>Nairobi, Kenya</p>\r\n', '2', 1);
INSERT INTO tbl_customer (`customer_id`, `customer_code`, `customer_name`, `email`, `phone`, `address`, `discount`, `country_id`) VALUES (2, 33336342, 'Wenton Maake', 'wendy@tharaka.com', '072272727272', '<p>Kampala,</p>\r\n\r\n<p>Uganda</p>\r\n', '0', 3);


#
# TABLE STRUCTURE FOR: tbl_damage_product
#

DROP TABLE IF EXISTS tbl_damage_product;

CREATE TABLE `tbl_damage_product` (
  `damage_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `product_code` int(11) NOT NULL,
  `product_name` varchar(127) NOT NULL,
  `category` varchar(128) NOT NULL,
  `country_id` int(11) NOT NULL,
  `qty` int(5) NOT NULL,
  `note` text NOT NULL,
  `decrease` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0= no; 1= yes',
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`damage_product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO tbl_damage_product (`damage_product_id`, `product_id`, `product_code`, `product_name`, `category`, `country_id`, `qty`, `note`, `decrease`, `date`) VALUES (1, 1, 89531411, 'FOIF RTS-010', 'Total Station > FOIF', 3, 1, 'bad', 1, '10 May, 2016');
INSERT INTO tbl_damage_product (`damage_product_id`, `product_id`, `product_code`, `product_name`, `category`, `country_id`, `qty`, `note`, `decrease`, `date`) VALUES (2, 2, 79522042, 'Tissues', 'Toiletries > Tissue Papers', 1, 10, 'Rejects', 1, '21 May, 2016');
INSERT INTO tbl_damage_product (`damage_product_id`, `product_id`, `product_code`, `product_name`, `category`, `country_id`, `qty`, `note`, `decrease`, `date`) VALUES (3, 1, 89531411, 'FOIF RTS-010', 'Total Station > FOIF', 1, 1, 'Not Zooming', 1, '21 May, 2016');


#
# TABLE STRUCTURE FOR: tbl_expense
#

DROP TABLE IF EXISTS tbl_expense;

CREATE TABLE `tbl_expense` (
  `expense_id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_code` varchar(11) NOT NULL,
  `expense_name` varchar(100) NOT NULL,
  `expense_note` text NOT NULL,
  `expense_amount` double NOT NULL,
  `expense_attachment` varchar(300) NOT NULL,
  `country_id` int(11) NOT NULL,
  `expense_date` date NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tbl_expense (`expense_id`, `expense_code`, `expense_name`, `expense_note`, `expense_amount`, `expense_attachment`, `country_id`, `expense_date`) VALUES (1, '71455331', 'LPO-SUPPLY 2016', '<p>This is an inclusion&nbsp;of application fee and Buying of Tender book</p>\r\n', '3000', '', 1, '2016-05-23');
INSERT INTO tbl_expense (`expense_id`, `expense_code`, `expense_name`, `expense_note`, `expense_amount`, `expense_attachment`, `country_id`, `expense_date`) VALUES (3, '11643833', 'Transport to Kisumu', '<p>Trip to kisumu Expo</p>\r\n', '1.09', '', 1, '2016-05-20');


#
# TABLE STRUCTURE FOR: tbl_inventory
#

DROP TABLE IF EXISTS tbl_inventory;

CREATE TABLE `tbl_inventory` (
  `inventory_id` int(5) NOT NULL AUTO_INCREMENT,
  `product_id` int(5) NOT NULL,
  `product_quantity_Kenya` int(11) NOT NULL,
  `product_quantity_Botswana` int(11) NOT NULL,
  `product_quantity_Uganda` int(11) NOT NULL,
  `notify_quantity` int(5) DEFAULT NULL,
  PRIMARY KEY (`inventory_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO tbl_inventory (`inventory_id`, `product_id`, `product_quantity_Kenya`, `product_quantity_Botswana`, `product_quantity_Uganda`, `notify_quantity`) VALUES (1, 1, 33, 10, 84, 30);
INSERT INTO tbl_inventory (`inventory_id`, `product_id`, `product_quantity_Kenya`, `product_quantity_Botswana`, `product_quantity_Uganda`, `notify_quantity`) VALUES (2, 2, 189, 3, 10, 10);


#
# TABLE STRUCTURE FOR: tbl_invoice
#

DROP TABLE IF EXISTS tbl_invoice;

CREATE TABLE `tbl_invoice` (
  `invoice_id` int(5) NOT NULL AUTO_INCREMENT,
  `invoice_no` int(11) DEFAULT NULL,
  `order_id` int(11) NOT NULL,
  `invoice_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`invoice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO tbl_invoice (`invoice_id`, `invoice_no`, `order_id`, `invoice_date`) VALUES (1, 45403171, 1, '2016-05-09 12:02:41');
INSERT INTO tbl_invoice (`invoice_id`, `invoice_no`, `order_id`, `invoice_date`) VALUES (2, 17420452, 2, '2016-05-09 20:04:48');
INSERT INTO tbl_invoice (`invoice_id`, `invoice_no`, `order_id`, `invoice_date`) VALUES (3, 18958263, 3, '2016-05-09 21:11:06');
INSERT INTO tbl_invoice (`invoice_id`, `invoice_no`, `order_id`, `invoice_date`) VALUES (4, 69313274, 5, '2016-05-09 22:58:15');
INSERT INTO tbl_invoice (`invoice_id`, `invoice_no`, `order_id`, `invoice_date`) VALUES (9, 34236679, 10, '2016-05-20 19:45:22');
INSERT INTO tbl_invoice (`invoice_id`, `invoice_no`, `order_id`, `invoice_date`) VALUES (10, 80425210, 11, '2016-05-21 12:28:47');


#
# TABLE STRUCTURE FOR: tbl_menu
#

DROP TABLE IF EXISTS tbl_menu;

CREATE TABLE `tbl_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `parent` int(5) NOT NULL,
  `sort` int(5) NOT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (1, 'Dashboard', 'admin/dashboard', 'fa fa-dashboard', 0, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (2, 'Settings', '#', 'fa fa-cogs', 0, 10);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (3, 'Business Profile', 'admin/settings/business_profile', 'glyphicon glyphicon-briefcase', 2, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (4, 'Employee Management', '#', 'entypo-users', 0, 9);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (5, 'Employee List', 'admin/employee/employee_list', 'fa fa-users', 4, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (6, 'Add Employee', 'admin/employee/add_employee', 'entypo-user-add', 4, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (7, 'Product', '#', 'glyphicon glyphicon-th-large', 0, 3);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (8, 'Category', '#', 'glyphicon glyphicon-indent-left', 7, 4);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (9, 'Product Category', 'admin/product/category', 'glyphicon glyphicon-tag', 8, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (10, 'Sub Category', 'admin/product/subcategory', 'glyphicon glyphicon-tags', 8, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (13, 'Add Product', 'admin/product/add_product', 'glyphicon glyphicon-plus', 7, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (14, 'Manage Product', 'admin/product/manage_product', 'glyphicon glyphicon-th-list', 7, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (17, 'Manage Tax Rules', 'admin/settings/tax', 'glyphicon glyphicon-credit-card', 2, 3);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (18, 'Manage Purchase', '#', 'fa fa-truck', 0, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (19, 'Supplier', '#', 'glyphicon glyphicon-gift', 18, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (20, 'Add Supplier', 'admin/purchase/add_supplier', 'glyphicon glyphicon-plus', 19, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (21, 'Manage Supplier', 'admin/purchase/manage_supplier', 'glyphicon glyphicon-briefcase', 19, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (22, 'Purchase', '#', 'glyphicon glyphicon-credit-card', 18, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (23, 'New Purchase', 'admin/purchase/new_purchase', 'glyphicon glyphicon-shopping-cart', 22, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (24, 'Purchase History', 'admin/purchase/purchase_list', 'glyphicon glyphicon-th-list', 22, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (25, 'Customer', '#', 'glyphicon glyphicon-user', 0, 5);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (26, 'Add Customer', 'admin/customer/add_customer', 'glyphicon glyphicon-plus', 25, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (27, 'Manage Customer', 'admin/customer/manage_customer', 'glyphicon glyphicon-th-list', 25, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (28, 'Damage Product', 'admin/product/damage_product', 'glyphicon glyphicon-trash', 7, 3);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (29, 'Barcode Print', 'admin/product/print_barcode', 'glyphicon glyphicon-barcode', 7, 5);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (30, 'Order Process', '#', 'glyphicon glyphicon-shopping-cart', 0, 4);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (31, 'New Order', 'admin/order/new_order', 'fa fa-cart-plus', 30, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (32, 'Manage Order', 'admin/order/manage_order', 'glyphicon glyphicon-th-list', 30, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (33, 'Manage Invoice', 'admin/order/manage_invoice', 'glyphicon glyphicon-list-alt', 30, 3);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (34, 'Report', 'admin/report', 'glyphicon glyphicon-signal', 0, 8);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (35, 'Sales Report', 'admin/report/sales_report', 'fa fa-bar-chart', 34, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (36, 'Purchase Report', 'admin/report/purchase_report', 'fa fa-line-chart', 34, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (37, 'Email Campaign', '#', 'glyphicon glyphicon-send', 0, 7);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (38, 'New campaign', 'admin/campaign/new_campaign', 'glyphicon glyphicon-envelope', 37, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (39, 'Manage Campaign', 'admin/campaign/manage_campaign', 'glyphicon glyphicon-th-list', 37, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (40, 'Camaign Result', 'admin/campaign/campaign_result', 'glyphicon glyphicon-bullhorn', 37, 3);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (41, 'Menu', '#', 'fa fa-bars', 2, 4);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (42, 'Add Menu', 'admin/navigation/add_navigation', 'glyphicon glyphicon-plus', 41, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (43, 'Menu Management', 'admin/navigation', 'glyphicon glyphicon-th-list', 41, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (44, 'Country', '#', 'fa fa-globe', 2, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (45, 'Add  Country', 'admin/country/add_country', 'glyphicon glyphicon-plus', 44, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (46, 'Manage Country', 'admin/country/manage_country', 'glyphicon glyphicon-th-list', 44, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (47, 'Expenses', '#', 'fa fa-bar-chart', 0, 6);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (48, 'Add  Expense', 'admin/expense/add_expense', 'glyphicon glyphicon-plus', 47, 1);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (49, 'Manage Expense', 'admin/expense/manage_expense', 'glyphicon glyphicon-th-list', 47, 2);
INSERT INTO tbl_menu (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`) VALUES (50, 'Expenses Report', 'admin/report/expense_report', 'fa fa-bar-chart', 34, 3);


#
# TABLE STRUCTURE FOR: tbl_order
#

DROP TABLE IF EXISTS tbl_order;

CREATE TABLE `tbl_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` int(10) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `customer_id` int(10) NOT NULL,
  `customer_name` varchar(128) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_phone` varchar(100) NOT NULL,
  `customer_address` text NOT NULL,
  `shipping_address` text NOT NULL,
  `sub_total` double NOT NULL,
  `discount` double NOT NULL,
  `discount_amount` double NOT NULL,
  `total_tax` double NOT NULL,
  `grand_total` double NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `payment_ref` varchar(120) NOT NULL,
  `order_status` int(2) NOT NULL DEFAULT '0' COMMENT '0= pending; 1= cancel; 2=confirm',
  `note` text NOT NULL,
  `sales_person` varchar(100) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO tbl_order (`order_id`, `order_no`, `order_date`, `customer_id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `shipping_address`, `sub_total`, `discount`, `discount_amount`, `total_tax`, `grand_total`, `payment_method`, `payment_ref`, `order_status`, `note`, `sales_person`, `country_id`) VALUES (1, 65582041, '2016-05-09 12:02:41', 1, 'SUSAN CLEMENT', 'tonini46@gmail.com', '0726574998', '<p>Nairobi, Kenya</p>\r\n', '<p>Kasarani,</p>\r\n\r\n<p>Nairobi, Kenya</p>\r\n', '13500', '0', '0', '2160', '15660', 'cash', '', 2, '<p>Pay so that we can begin Shipping.</p>\r\n', 'Chris Muya', 1);
INSERT INTO tbl_order (`order_id`, `order_no`, `order_date`, `customer_id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `shipping_address`, `sub_total`, `discount`, `discount_amount`, `total_tax`, `grand_total`, `payment_method`, `payment_ref`, `order_status`, `note`, `sales_person`, `country_id`) VALUES (2, 39227762, '2016-05-09 20:04:47', 2, 'Wenton Maake', 'wendy@tharaka.com', '072272727272', '<p>Kampala,</p>\r\n\r\n<p>Uganda</p>\r\n', '<p>Kampala, Uganda</p>\r\n', '13500', '0', '0', '2160', '15660', 'cash', '', 2, '<p>Kampala, Uganda</p>\r\n', 'Wendy Makena', 3);
INSERT INTO tbl_order (`order_id`, `order_no`, `order_date`, `customer_id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `shipping_address`, `sub_total`, `discount`, `discount_amount`, `total_tax`, `grand_total`, `payment_method`, `payment_ref`, `order_status`, `note`, `sales_person`, `country_id`) VALUES (3, 39916603, '2016-05-09 21:11:06', 0, 'Walking Client', '', '', '', '', '13500', '0', '0', '2160', '15660', 'cash', '', 2, '', 'Wendy Makena', 3);
INSERT INTO tbl_order (`order_id`, `order_no`, `order_date`, `customer_id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `shipping_address`, `sub_total`, `discount`, `discount_amount`, `total_tax`, `grand_total`, `payment_method`, `payment_ref`, `order_status`, `note`, `sales_person`, `country_id`) VALUES (4, 77440404, '2016-05-09 21:41:13', 2, 'Wenton Maake', 'wendy@tharaka.com', '072272727272', '<p>Kampala,</p>\r\n\r\n<p>Uganda</p>\r\n', '', '13500', '0', '0', '2160', '15660', '', '', 0, '', 'Wendy Makena', 3);
INSERT INTO tbl_order (`order_id`, `order_no`, `order_date`, `customer_id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `shipping_address`, `sub_total`, `discount`, `discount_amount`, `total_tax`, `grand_total`, `payment_method`, `payment_ref`, `order_status`, `note`, `sales_person`, `country_id`) VALUES (5, 31982825, '2016-05-09 22:58:15', 1, 'SUSAN CLEMENT', 'tonini46@gmail.com', '0726574998', '<p>Nairobi, Kenya</p>\r\n', '', '27000', '0', '0', '4320', '31320', 'cash', '', 2, '', 'Chris Muya', 1);
INSERT INTO tbl_order (`order_id`, `order_no`, `order_date`, `customer_id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `shipping_address`, `sub_total`, `discount`, `discount_amount`, `total_tax`, `grand_total`, `payment_method`, `payment_ref`, `order_status`, `note`, `sales_person`, `country_id`) VALUES (10, 499018010, '2016-05-20 19:45:22', 1, 'SUSAN CLEMENT', 'tonini46@gmail.com', '0726574998', '<p>Nairobi, Kenya</p>\r\n', '', '500', '0', '0', '80', '580', 'cash', '', 2, '', 'Chris Muya', 1);
INSERT INTO tbl_order (`order_id`, `order_no`, `order_date`, `customer_id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `shipping_address`, `sub_total`, `discount`, `discount_amount`, `total_tax`, `grand_total`, `payment_method`, `payment_ref`, `order_status`, `note`, `sales_person`, `country_id`) VALUES (11, 378682011, '2016-05-21 12:28:47', 1, 'SUSAN CLEMENT', 'tonini46@gmail.com', '0726574998', '<p>Nairobi, Kenya</p>\r\n', '', '25', '0', '0', '4', '29', 'cash', '', 2, '', 'Chris Muya', 1);


#
# TABLE STRUCTURE FOR: tbl_order_details
#

DROP TABLE IF EXISTS tbl_order_details;

CREATE TABLE `tbl_order_details` (
  `order_details_id` int(10) NOT NULL AUTO_INCREMENT,
  `order_id` int(10) NOT NULL,
  `product_code` int(10) NOT NULL,
  `product_name` varchar(128) NOT NULL,
  `product_quantity` int(5) NOT NULL,
  `buying_price` double NOT NULL,
  `selling_price` double NOT NULL,
  `product_tax` double NOT NULL,
  `sub_total` double NOT NULL,
  `price_option` varchar(100) NOT NULL,
  PRIMARY KEY (`order_details_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO tbl_order_details (`order_details_id`, `order_id`, `product_code`, `product_name`, `product_quantity`, `buying_price`, `selling_price`, `product_tax`, `sub_total`, `price_option`) VALUES (1, 1, 89531411, 'FOIF RTS-010', 1, '12500', '13500', '2160', '13500', 'general');
INSERT INTO tbl_order_details (`order_details_id`, `order_id`, `product_code`, `product_name`, `product_quantity`, `buying_price`, `selling_price`, `product_tax`, `sub_total`, `price_option`) VALUES (2, 2, 89531411, 'FOIF RTS-010', 1, '12500', '13500', '2160', '13500', 'general');
INSERT INTO tbl_order_details (`order_details_id`, `order_id`, `product_code`, `product_name`, `product_quantity`, `buying_price`, `selling_price`, `product_tax`, `sub_total`, `price_option`) VALUES (3, 3, 89531411, 'FOIF RTS-010', 1, '12500', '13500', '2160', '13500', 'general');
INSERT INTO tbl_order_details (`order_details_id`, `order_id`, `product_code`, `product_name`, `product_quantity`, `buying_price`, `selling_price`, `product_tax`, `sub_total`, `price_option`) VALUES (4, 4, 89531411, 'FOIF RTS-010', 1, '12500', '13500', '2160', '13500', 'general');
INSERT INTO tbl_order_details (`order_details_id`, `order_id`, `product_code`, `product_name`, `product_quantity`, `buying_price`, `selling_price`, `product_tax`, `sub_total`, `price_option`) VALUES (5, 5, 89531411, 'FOIF RTS-010', 2, '12500', '13500', '4320', '27000', 'general');
INSERT INTO tbl_order_details (`order_details_id`, `order_id`, `product_code`, `product_name`, `product_quantity`, `buying_price`, `selling_price`, `product_tax`, `sub_total`, `price_option`) VALUES (6, 6, 79522042, 'Tissues', 1, '20', '25', '4', '25', 'general');
INSERT INTO tbl_order_details (`order_details_id`, `order_id`, `product_code`, `product_name`, `product_quantity`, `buying_price`, `selling_price`, `product_tax`, `sub_total`, `price_option`) VALUES (7, 7, 79522042, 'Tissues', 1, '20', '25', '4', '25', 'general');
INSERT INTO tbl_order_details (`order_details_id`, `order_id`, `product_code`, `product_name`, `product_quantity`, `buying_price`, `selling_price`, `product_tax`, `sub_total`, `price_option`) VALUES (8, 8, 79522042, 'Tissues', 1, '20', '25', '4', '25', 'general');
INSERT INTO tbl_order_details (`order_details_id`, `order_id`, `product_code`, `product_name`, `product_quantity`, `buying_price`, `selling_price`, `product_tax`, `sub_total`, `price_option`) VALUES (9, 9, 89531411, 'FOIF RTS-010', 1, '12500', '13500', '2970', '13500', 'general');
INSERT INTO tbl_order_details (`order_details_id`, `order_id`, `product_code`, `product_name`, `product_quantity`, `buying_price`, `selling_price`, `product_tax`, `sub_total`, `price_option`) VALUES (10, 10, 79522042, 'Tissues', 20, '20', '25', '80', '500', 'general');
INSERT INTO tbl_order_details (`order_details_id`, `order_id`, `product_code`, `product_name`, `product_quantity`, `buying_price`, `selling_price`, `product_tax`, `sub_total`, `price_option`) VALUES (11, 11, 79522042, 'Tissues', 1, '20', '25', '4', '25', 'general');


#
# TABLE STRUCTURE FOR: tbl_product
#

DROP TABLE IF EXISTS tbl_product;

CREATE TABLE `tbl_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_code` varchar(100) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_note` text NOT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '0=Inactive,1=Active',
  `subcategory_id` int(5) NOT NULL,
  `barcode_path` varchar(300) NOT NULL,
  `barcode` varchar(100) NOT NULL,
  `tax_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO tbl_product (`product_id`, `product_code`, `product_name`, `product_note`, `status`, `subcategory_id`, `barcode_path`, `barcode`, `tax_id`) VALUES (1, '89531411', 'FOIF RTS-010', '', 1, 1, 'C:\\xampp\\htdocs\\inventory\\easy_inventory/img/barcode/89531411.jpg', 'img/barcode/89531411.jpg', 2);
INSERT INTO tbl_product (`product_id`, `product_code`, `product_name`, `product_note`, `status`, `subcategory_id`, `barcode_path`, `barcode`, `tax_id`) VALUES (2, '79522042', 'Tissues', '', 1, 5, 'C:\\xampp\\htdocs\\inventory\\easy_inventory/img/barcode/79522042.jpg', 'img/barcode/79522042.jpg', 3);


#
# TABLE STRUCTURE FOR: tbl_product_image
#

DROP TABLE IF EXISTS tbl_product_image;

CREATE TABLE `tbl_product_image` (
  `product_image_id` int(5) NOT NULL AUTO_INCREMENT,
  `product_id` int(5) NOT NULL,
  `image_path` varchar(300) NOT NULL,
  `filename` varchar(100) NOT NULL,
  PRIMARY KEY (`product_image_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_product_price
#

DROP TABLE IF EXISTS tbl_product_price;

CREATE TABLE `tbl_product_price` (
  `product_price_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(5) NOT NULL,
  `buying_price` double NOT NULL,
  `selling_price` double NOT NULL,
  PRIMARY KEY (`product_price_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO tbl_product_price (`product_price_id`, `product_id`, `buying_price`, `selling_price`) VALUES (1, 1, '12500', '13500');
INSERT INTO tbl_product_price (`product_price_id`, `product_id`, `buying_price`, `selling_price`) VALUES (2, 2, '20', '25');


#
# TABLE STRUCTURE FOR: tbl_product_tag
#

DROP TABLE IF EXISTS tbl_product_tag;

CREATE TABLE `tbl_product_tag` (
  `product_tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `tag` varchar(100) NOT NULL,
  PRIMARY KEY (`product_tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_purchase
#

DROP TABLE IF EXISTS tbl_purchase;

CREATE TABLE `tbl_purchase` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_order_number` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(128) NOT NULL,
  `grand_total` int(5) NOT NULL,
  `purchase_ref` varchar(128) NOT NULL,
  `payment_method` varchar(128) NOT NULL,
  `payment_ref` varchar(128) NOT NULL,
  `purchase_by` varchar(100) NOT NULL,
  `country_id` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`purchase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO tbl_purchase (`purchase_id`, `purchase_order_number`, `supplier_id`, `supplier_name`, `grand_total`, `purchase_ref`, `payment_method`, `payment_ref`, `purchase_by`, `country_id`, `datetime`) VALUES (1, 16366031, 1, 'Tazamali Ltd', 400, '2wa2', 'cash', '', 'Super Admin', 1, '2016-05-22 08:01:46');
INSERT INTO tbl_purchase (`purchase_id`, `purchase_order_number`, `supplier_id`, `supplier_name`, `grand_total`, `purchase_ref`, `payment_method`, `payment_ref`, `purchase_by`, `country_id`, `datetime`) VALUES (2, 9453442, 1, 'Tazamali Ltd', 400, 'dfdsfdsf', 'cash', '', 'Super Admin', 1, '2016-05-22 08:01:54');
INSERT INTO tbl_purchase (`purchase_id`, `purchase_order_number`, `supplier_id`, `supplier_name`, `grand_total`, `purchase_ref`, `payment_method`, `payment_ref`, `purchase_by`, `country_id`, `datetime`) VALUES (3, 83987433, 1, 'Tazamali Ltd', 2000, 'sku-100', 'cash', '', 'Super Admin', 3, '2016-05-22 08:01:57');
INSERT INTO tbl_purchase (`purchase_id`, `purchase_order_number`, `supplier_id`, `supplier_name`, `grand_total`, `purchase_ref`, `payment_method`, `payment_ref`, `purchase_by`, `country_id`, `datetime`) VALUES (4, 83987434, 1, 'Tazamali Ltd', 0, 'sku-100', 'cash', '', 'Super Admin', 1, '2016-05-22 08:02:00');
INSERT INTO tbl_purchase (`purchase_id`, `purchase_order_number`, `supplier_id`, `supplier_name`, `grand_total`, `purchase_ref`, `payment_method`, `payment_ref`, `purchase_by`, `country_id`, `datetime`) VALUES (5, 13432415, 1, 'Tazamali Ltd', 2000, 'sku-1011', 'cash', '', 'Super Admin', 1, '2016-05-22 08:02:05');
INSERT INTO tbl_purchase (`purchase_id`, `purchase_order_number`, `supplier_id`, `supplier_name`, `grand_total`, `purchase_ref`, `payment_method`, `payment_ref`, `purchase_by`, `country_id`, `datetime`) VALUES (6, 64056316, 1, 'Tazamali Ltd', 2000, 'soap-100', 'cash', '', 'Super Admin', 1, '2016-05-22 08:02:08');
INSERT INTO tbl_purchase (`purchase_id`, `purchase_order_number`, `supplier_id`, `supplier_name`, `grand_total`, `purchase_ref`, `payment_method`, `payment_ref`, `purchase_by`, `country_id`, `datetime`) VALUES (7, 84159647, 1, 'Tazamali Ltd', 20000, 'tz2016', 'cash', '', 'Super Admin', 2, '2016-05-22 08:02:21');
INSERT INTO tbl_purchase (`purchase_id`, `purchase_order_number`, `supplier_id`, `supplier_name`, `grand_total`, `purchase_ref`, `payment_method`, `payment_ref`, `purchase_by`, `country_id`, `datetime`) VALUES (8, 93416728, 1, 'Tazamali Ltd', 2000, 'tissue', 'cash', '', 'Super Admin', 2, '2016-05-22 08:02:18');
INSERT INTO tbl_purchase (`purchase_id`, `purchase_order_number`, `supplier_id`, `supplier_name`, `grand_total`, `purchase_ref`, `payment_method`, `payment_ref`, `purchase_by`, `country_id`, `datetime`) VALUES (9, 19085159, 1, 'Tazamali Ltd', 20, '123', 'cash', '', 'Super Admin', 2, '2016-05-22 08:01:20');
INSERT INTO tbl_purchase (`purchase_id`, `purchase_order_number`, `supplier_id`, `supplier_name`, `grand_total`, `purchase_ref`, `payment_method`, `payment_ref`, `purchase_by`, `country_id`, `datetime`) VALUES (10, 701894310, 1, 'Tazamali Ltd', 20, 'kamata', 'cash', '', 'Super Admin', 1, '2016-05-23 01:00:38');
INSERT INTO tbl_purchase (`purchase_id`, `purchase_order_number`, `supplier_id`, `supplier_name`, `grand_total`, `purchase_ref`, `payment_method`, `payment_ref`, `purchase_by`, `country_id`, `datetime`) VALUES (11, 883954211, 1, 'Tazamali Ltd', 12520, 'fggg5677', 'cash', '', 'Super Admin', 1, '2016-06-12 07:33:15');


#
# TABLE STRUCTURE FOR: tbl_purchase_product
#

DROP TABLE IF EXISTS tbl_purchase_product;

CREATE TABLE `tbl_purchase_product` (
  `purchase_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `product_name` varchar(128) NOT NULL,
  `qty` int(5) NOT NULL,
  `unit_price` int(5) NOT NULL,
  `sub_total` int(5) NOT NULL,
  PRIMARY KEY (`purchase_product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (1, 1, 'sku-89299', 'Tissues', 20, 20, 400);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (2, 2, '79522042', 'Tissues', 20, 20, 400);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (3, 3, '79522042', 'Tissues', 100, 20, 2000);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (4, 5, '79522042', 'Tissues', 100, 20, 2000);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (5, 6, 'sku-58626', 'Ushindi soap', 20, 100, 2000);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (6, 7, 'sku-28855', 'Towels', 10, 2000, 20000);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (7, 8, '79522042', 'Tissues', 100, 20, 2000);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (8, 0, '79522042', 'Tissues', 20, 20, 400);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (9, 0, '79522042', 'Tissues', 1, 20, 20);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (10, 0, '79522042', 'Tissues', 1, 20, 20);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (11, 9, '79522042', 'Tissues', 1, 20, 20);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (12, 10, '79522042', 'Tissues', 1, 20, 20);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (13, 11, '79522042', 'Tissues', 1, 20, 20);
INSERT INTO tbl_purchase_product (`purchase_product_id`, `purchase_id`, `product_code`, `product_name`, `qty`, `unit_price`, `sub_total`) VALUES (14, 11, '89531411', 'FOIF RTS-010', 1, 12500, 12500);


#
# TABLE STRUCTURE FOR: tbl_special_offer
#

DROP TABLE IF EXISTS tbl_special_offer;

CREATE TABLE `tbl_special_offer` (
  `special_offer_id` int(5) NOT NULL AUTO_INCREMENT,
  `product_id` int(5) NOT NULL,
  `offer_price` double DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`special_offer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_subcategory
#

DROP TABLE IF EXISTS tbl_subcategory;

CREATE TABLE `tbl_subcategory` (
  `subcategory_id` int(5) NOT NULL AUTO_INCREMENT,
  `category_id` int(5) NOT NULL,
  `subcategory_name` varchar(100) NOT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`subcategory_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO tbl_subcategory (`subcategory_id`, `category_id`, `subcategory_name`, `created_datetime`) VALUES (1, 1, 'FOIF', '2016-05-09 11:12:06');
INSERT INTO tbl_subcategory (`subcategory_id`, `category_id`, `subcategory_name`, `created_datetime`) VALUES (4, 1, 'PENTAX', '2016-05-09 11:27:54');
INSERT INTO tbl_subcategory (`subcategory_id`, `category_id`, `subcategory_name`, `created_datetime`) VALUES (5, 2, 'Tissue Papers', '2016-05-10 10:23:55');
INSERT INTO tbl_subcategory (`subcategory_id`, `category_id`, `subcategory_name`, `created_datetime`) VALUES (6, 2, 'Soap', '2016-05-20 12:07:04');


#
# TABLE STRUCTURE FOR: tbl_supplier
#

DROP TABLE IF EXISTS tbl_supplier;

CREATE TABLE `tbl_supplier` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) NOT NULL,
  `supplier_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` text NOT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO tbl_supplier (`supplier_id`, `company_name`, `supplier_name`, `email`, `phone`, `address`) VALUES (1, 'Tazamali Ltd', 'tazamali', 'taz@gmail.com', '0788154145', '<p>Upper Hill</p>\r\n');


#
# TABLE STRUCTURE FOR: tbl_tag
#

DROP TABLE IF EXISTS tbl_tag;

CREATE TABLE `tbl_tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(100) NOT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_tax
#

DROP TABLE IF EXISTS tbl_tax;

CREATE TABLE `tbl_tax` (
  `tax_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_title` varchar(100) NOT NULL,
  `tax_rate` double NOT NULL,
  `tax_type` int(2) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tbl_tax (`tax_id`, `tax_title`, `tax_rate`, `tax_type`, `country_id`) VALUES (1, 'VAT-KENYA', '16', 1, 1);
INSERT INTO tbl_tax (`tax_id`, `tax_title`, `tax_rate`, `tax_type`, `country_id`) VALUES (2, 'VAT-UGANDA', '22', 1, 3);
INSERT INTO tbl_tax (`tax_id`, `tax_title`, `tax_rate`, `tax_type`, `country_id`) VALUES (3, 'VAT-BOTSWANA', '10', 1, 2);


#
# TABLE STRUCTURE FOR: tbl_tier_price
#

DROP TABLE IF EXISTS tbl_tier_price;

CREATE TABLE `tbl_tier_price` (
  `tier_price_id` int(5) NOT NULL AUTO_INCREMENT,
  `product_id` int(5) NOT NULL,
  `tier_price` double NOT NULL,
  `quantity_above` int(5) NOT NULL,
  PRIMARY KEY (`tier_price_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_user
#

DROP TABLE IF EXISTS tbl_user;

CREATE TABLE `tbl_user` (
  `user_id` int(5) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `filename` varchar(128) NOT NULL,
  `image_path` varchar(128) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '0',
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO tbl_user (`user_id`, `user_name`, `name`, `email`, `password`, `filename`, `image_path`, `flag`, `country_id`) VALUES (0, 'measurem', 'Super Admin', 'info@measurementsystems.co.ke', '9ddf3f96d1d276a769838cf0e0f0a2f82cc7b4fe99823e73c9f139d574adf0ba9d0ba617567fe4641690b37eef16df4afc8c29555933f620e9a2d61b5e02b4c6', '', '', 1, 0);
INSERT INTO tbl_user (`user_id`, `user_name`, `name`, `email`, `password`, `filename`, `image_path`, `flag`, `country_id`) VALUES (1, 'wenton', 'Wendy Makena', 'wendy41@gmail.com', '9ddf3f96d1d276a769838cf0e0f0a2f82cc7b4fe99823e73c9f139d574adf0ba9d0ba617567fe4641690b37eef16df4afc8c29555933f620e9a2d61b5e02b4c6', '', '', 0, 3);
INSERT INTO tbl_user (`user_id`, `user_name`, `name`, `email`, `password`, `filename`, `image_path`, `flag`, `country_id`) VALUES (2, 'cmuya', 'Chris Muya', 'chrismuya61@gmail.com', '9ddf3f96d1d276a769838cf0e0f0a2f82cc7b4fe99823e73c9f139d574adf0ba9d0ba617567fe4641690b37eef16df4afc8c29555933f620e9a2d61b5e02b4c6', '', '', 0, 1);


#
# TABLE STRUCTURE FOR: tbl_user_role
#

DROP TABLE IF EXISTS tbl_user_role;

CREATE TABLE `tbl_user_role` (
  `user_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_login_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY (`user_role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8;

INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (155, 1, 1);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (156, 1, 7);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (157, 1, 14);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (158, 1, 28);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (159, 1, 29);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (160, 1, 25);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (161, 1, 26);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (162, 1, 27);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (163, 1, 30);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (164, 1, 31);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (165, 1, 32);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (166, 1, 33);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (167, 1, 47);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (168, 1, 48);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (169, 1, 49);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (170, 2, 1);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (171, 2, 7);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (172, 2, 14);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (173, 2, 28);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (174, 2, 29);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (175, 2, 25);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (176, 2, 26);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (177, 2, 27);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (178, 2, 30);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (179, 2, 31);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (180, 2, 32);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (181, 2, 33);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (182, 2, 47);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (183, 2, 48);
INSERT INTO tbl_user_role (`user_role_id`, `employee_login_id`, `menu_id`) VALUES (184, 2, 49);


